name = 'iterview'
loglevel = 'info'
errorlog = '-'
accesslog = '='
workers = 2