from django.apps import AppConfig


class IterviewConfig(AppConfig):
    name = 'iterview'
