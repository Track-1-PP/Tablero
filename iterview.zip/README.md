

## Proyecto epico Programacion Profesional

  
Requisitos: Python3, Django (minimo v3.1.5)
```

Hasta ahora la plataforma se basa en: Inicio, Registrar Postulante, Registrar Entrevistador, Sign In, videollamada, Agenda, miusuario, ambiente programacion, ambiente ambientePizarra y una sección admin

```

links relevantes:
 
/miusuario
/miusuario_entrevistador
/agenda
/videollamada
/ambientepizzara
/ambienteprogramacion
/admin

**Creditos**
-Felipe Cornejo
-Andres Hernandez
-Martin Roca
-Allan Sifri
-Matias Vidal