## ADMIN

*En este archivo se encuentra la aplicación de admin.*

En el caso de admin solamente se va a poder acceder agregando /admin al link, posteriormente se debe iniciar sesión con una cuenta de administrador, los datos de esta cuenta serían:
```
Usuario: admin
Contraseña: programacionprofesional
```

De esta manera tenemos acceso **TOTAL** a la base de datos y podemos modificar las cosas que necesitemos o debamos. 


En la base de datos encontramos las cuentas de usuarios (entrevistador y entrevistado), podemos modificar sus roles y datos a necesidad, podemos agendar reuniones, agregar empresas, revisar reuniones agendadas, generar grupos de usuarios (para agruparlos por empresa).