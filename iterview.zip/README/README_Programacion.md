## Ambiente de Programacion

*En este archivo se encuentra la aplicación de la ambienteProgramacion y sus componentes estéticos que se encuentran en la carpeta templates.*

En el caso de el ambienteProgramacion solamente se va a poder acceder una vez que el usuario este dentro de una videollamada

en urls.py se pueden encontrar las ubicaciones a las que se pueden acceder desde esta aplicación

en views.py se ve el webrequest que solicita la aplicación cuando se le accede