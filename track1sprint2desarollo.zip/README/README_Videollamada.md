## Videollamada

*En este archivo se encuentra la aplicación de la Videollamada y sus componentes estéticos que se encuentran en la carpeta templates.*


En el caso de Videollamada solamente se va a poder acceder una vez que el usuario tenga una reunión agendada


Al acceder a esta sección, nos encontraremos con la videollamada y 3 botones, los cuales son para abrir una pestaña con un chat, una pizarra para dibujar y un ambiente de programación, los cuales se podrán usar para ayudar a la comunicación entre usuarios durante una entrevista.

En **urls.py** se pueden encontrar las ubicaciones a las que se pueden acceder desde esta aplicación

En **views.py** se ve el webrequest que solicita la aplicación cuando se le accede