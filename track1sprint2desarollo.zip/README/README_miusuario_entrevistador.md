## miusuario_entrevistador
*En este archivo se encuentra la aplicación de usuario entrevistador*

Este caso por ahora solo se podrá acceder a esta pestaña agregando /miusuario_entrevistador, en esta pestaña podemos ver un perfil para los entrevistadores en el cual se podrán ver los datos de los entrevistados. 

Los datos que se podrán ver son:

```
Nombre entrevistado | Carrera | Cargo | Curriculum | Nota entrevista | Contacto | Fecha y hora
```

En el caso del currículum este deberá ser subido a la plataforma para que posteriormente se pueda ver en línea por la aplicación. (en la sección de currículum, se habilitará un botón para ver el currículum de la persona)

También como entrevistador, podrán crear las video llamadas para las reuniones, también modificar y ver sus reuniones.